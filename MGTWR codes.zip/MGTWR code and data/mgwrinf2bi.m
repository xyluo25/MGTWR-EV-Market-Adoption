function result= mgwrinf2bi(bdwt,y,x,D,SD,f0,j,S,R,M)
n= size(x,1);
e0=y-sum(f0,2)+f0(:,j);
for iter = 1:n
wt = zeros(n,1);        
a=SD(iter,bdwt);
index=find(D(iter,:)<=a+0.1^10);
wt(index)=((1-(D(iter,index).^2)./(a^2)).^2)'; 
Wi=diag(wt);
C=inv(x(:,j)'*Wi*x(:,j))*x(:,j)'*Wi;
r(iter,:)=x(iter,j)*C;
cm(iter,:)=C;
end % end of for iter loop
%r is the hat matrix of local
ehat=r*e0;
newf0=f0;
newf0(:,j)=ehat;
res=e0-ehat;
Aj=r;
newR=R;
newR(:,:,j)=Aj-Aj*S+Aj*R(:,:,j);
newM=M;
newM(:,:,j)=cm-cm*S+cm*R(:,:,j);
newS=S-R(:,:,j)+newR(:,:,j);
result.bdwt=bdwt;
result.f0=newf0;
result.yhat=newS*y;
result.S=newS;
result.R=newR;
result.M=newM;
result.res=res;
result.ssr=res'*res;
end