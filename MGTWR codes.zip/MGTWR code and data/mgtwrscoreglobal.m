function score= mgtwrscoreglobal(bd,y,x,D,SD)
[NT,K]= size(x);
bdwt=[bd(1:K);bd(1+K:2*K)];
f0=zeros(NT,K);
S=zeros(NT,NT);
R=zeros(NT,NT,K);
ssr1=y'*y;
tor=1;
n= size(D,1);T=NT/n;
while tor>1*10^-3
ssr0=ssr1;o=1;
for j=1:K
o=o+1;
bs=bdwt(1,j);bt=bdwt(2,j);
e0=y-sum(f0,2)+f0(:,j);
r=zeros(NT,NT);
for time =1:T
wt=zeros(T,1);
index2=find(abs(time*ones(T,1)-(1:T)')<=bt);
Z=(ones(T,1)-(time*ones(T,1)-[1:T]').^2./(bt^2)).^2;
wt(index2)=Z(index2);
for iter = 1:n
ws = zeros(n,1);        
a=SD(iter,bs);
index=find(D(iter,:)<=a+0.1^10);
ws(index)=((1-(D(iter,index).^2)./(a^2)).^2)'; 
w=kron(wt,ws);
wx=w.*x(:,j);
C=(x(:,j)'*wx)\wx';
r(iter+(time-1)*n,:)=x(iter+(time-1)*n,j)*C;
end
end
f0(:,j)=r*e0;
rj=r-r*S+r*R(:,:,j);
S=S-R(:,:,j)+rj;
R(:,:,j)=rj;
end
res=e0-r*e0;
ssr1=res'*res;
tor=abs((ssr1-ssr0)/ssr0);
end
v1=trace(S);
score=NT*log(ssr1/NT)+NT*log(2*pi)+NT*(NT+v1)/(NT-2-v1);