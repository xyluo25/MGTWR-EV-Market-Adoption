function score= mgwrscore2bi(bdwt,y,x,D,SD,f0,j)
n= size(x,1);
e0=y-sum(f0,2)+f0(:,j);
r=zeros(n,n);
for iter = 1:n
wt = zeros(n,1);        
a=SD(iter,bdwt);
index=find(D(iter,:)<=a+0.1^10);
wt(index)=((1-(D(iter,index).^2)./(a^2)).^2)'; 
wx=wt.*x(:,j);
C=(x(:,j)'*wx)\wx';
r(iter,:)=x(iter,j)*C;
end
S=r;
ehat=S*e0;
res=e0-ehat;
v1=trace(S);
score=n*log((res'*res)/n)+n*log(2*pi)+n*(n+v1)/(n-2-v1);
if (n-2-v1)<0
score=inf;
end
end