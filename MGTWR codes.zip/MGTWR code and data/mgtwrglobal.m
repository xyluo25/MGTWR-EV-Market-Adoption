function result=mgtwrglobal(y,x,east,north)
% N regions*T time periods, Supply data sorted first by time and then by
% spatial units, so first region 1, region 2, et cetera, in the first year,
% then region 1, region 2, in the second year, and so on.
% east,north are the coordinates corresponding to the area.
% x should be balanced, but we can do an unbalanced
D=pdist2([east,north],[east,north]);
SD=sort(D)';
N= size(east,1);[NT,K]=size(x);T=NT/N;
A=[];
B=[];
intcon=1:(2*K);
lb=[5*ones(K,1);ones(K,1)];
flag=1;
while flag==1
    flag=0;
for time =1:T
for iter = 1:N     
for j=2:K
    a=SD(iter,lb(j));
    index=find(D(iter,:)<=a+0.1^10)+(time-1)*N;
    xij=x(index,j);
    if length(unique(xij))==1
        lb(j)=lb(j)+1;
        flag=1;
        break
    end
end
if flag==1
    break
end
end
if flag==1
    break
end
end
end
ub=[N*ones(K,1);T*ones(K,1)];
options = optimoptions('ga','UseParallel',true,'PlotFcn', @gaplotbestf);
re=ga(@(bd)mgtwrscoreglobal(bd,y,x,D,SD),2*K,A,B,[],[],lb,ub,[],intcon,options);
bdwt=[re(1:K);re(1+K:2*K)];
f0=zeros(NT,K);
S=zeros(NT,NT);
R=zeros(NT,NT,K);
M=zeros(NT,NT,K);
ssr1=y'*y;
tor=1;
iteration=1;
[NT,K]= size(x);
while tor>1*10^-5
ssr0=ssr1;o=1;
for j=1:K
o=o+1;
result= mgtwrinf(bdwt(:,j),y,x,D,SD,f0,j,S,R,M);
f0=result.f0;
S=result.S;
R=result.R;
M=result.M;
end
iteration=iteration+1;
ssr1=result.ssr;
tor=abs((ssr1-ssr0)/ssr0);
end
v1=trace(S);
v2=trace(S'*S);
var=zeros(NT,K);
for p=1:K
var(:,p)=diag(M(:,:,p)*M(:,:,p)')*(result.res'*result.res)/(NT-2*v1+v2);
result.beta(:,p)=M(:,:,p)*y;
end
se=sqrt(var);
t=result.beta./se;
sigma=sqrt(result.ssr/(NT-2*v1+v2));
score=NT*log(result.ssr/NT)+NT*log(2*pi)+NT*(NT+v1)/(NT-2-v1);
result.se=se;
result.t=t;
result.iteration=o-2;
result.v1=v1;
result.v2=v2;
result.sigma=sigma;
result.var=var;
result.bdwt=re;
result.score=score;
result.r2=1-result.ssr/sum((y-mean(y)).^2);
result.resid=result.res;