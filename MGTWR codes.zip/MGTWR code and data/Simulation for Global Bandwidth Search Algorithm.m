ox=12;%20
ot=12;%8
ob=ox^2*ot;

east=zeros(ob,1);north=zeros(ob,1);T=zeros(ob,1);
for i=1:ob
    east(i)=mod((i-1),ox)+1;
    north(i)=floor((mod((i-1),ox^2))/ox)+1;
    T(i)=floor((i-1)/ox^2)+1;
end

east0=east(1:144);
north0=north(1:144);
b0=5*ones(ob,1);
b2=3+(36-(6-east).^2).*(36-(6-north).^2).*(36-(6-T).^2)/144;
b1=3+(east+north+T)/6;

m=400;
[i,j] = meshgrid(min(east0):(max(east0)-min(east0))/m:max(east0),min(north0):(max(north0)-min(north0))/m:max(north0));
xmin=min(east0);
xmax=max(east0);
ymin=min(north0);
ymax=max(north0);
for t=1
figure
b= b2((1+144*(t-1)):(144+144*(t-1)));
Z1=griddata(east0,north0,reshape(b,144,1),i,j,'nearest');
zmin=min(reshape(b,144,1));
zmax=max(reshape(b,144,1));
mesh(i,j,Z1);
axis([xmin xmax ymin ymax]);
view(2);
colorbar
colormap jet
hold on
plot3(east0,north0,zmax*ones(size(east0)),'black.','markersize',10);
hold off
end