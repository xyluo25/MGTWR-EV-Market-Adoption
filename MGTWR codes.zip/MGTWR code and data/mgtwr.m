function result=mgtwr(y,x,east,north)
t1=clock;
% N regions*T time periods, Supply data sorted first by time and then by
% spatial units, so first region 1, region 2, et cetera, in the first year,
% then region 1, region 2, in the second year, and so on.
% east,north are the coordinates corresponding to the area.
% x should be balanced, but we can do an unbalanced
[NT,K]= size(x);
N=size(east,1);
T=NT/N;
D=pdist2([east,north],[east,north]);
SD=sort(D)';
%r0=gtwr(y,x,east,north);
%f0=r0.beta.*x;
%S=r0.S;
%R=r0.R;
%M=r0.M;
%ssr1=r0.ssr;

f0=zeros(NT,K);
S=zeros(NT,NT);
R=zeros(NT,NT,K);
M=zeros(NT,NT,K);
ssr1=y'*y;

tor=1;
iteration=1;
%here we have 2 kind bandwidths bs for spatial and bt for time. Each have k
%value for k variables.

A=[];
B=[];
intcon=[1,2];

lb=[5 1];
ub=[N T];%include itself
%x0=[round(rand(40,1)*N),round(rand(40,1)*T)];
%options=gaoptimset('Generations',200,'StallGenLimit',100,'PopulationSize',40,'TolFun',1e-15,'TolCon',1e-15,'UseParallel','always','MigrationFraction',0.2,'CrossoverFraction',0.8,'InitialPopulation',x0);
options = optimoptions('ga','UseParallel',true,'PlotFcn', @gaplotbestf);
bandwidth=zeros(2,K);
iterbdwt=zeros(2,K,1000);
while tor>1*10^-3
ssr0=ssr1;o=1;
for j=1:K

re=ga(@(bdwt)mgtwrscore(bdwt,y,x,D,SD,f0,j),2,A,B,[],[],lb,ub,[],intcon,options);
iterbdwt(1:2,o,iteration)=re;
o=o+1;

result= mgtwrinf(re,y,x,D,SD,f0,j,S,R,M);
f0=result.f0;
S=result.S;
R=result.R;
M=result.M;
bandwidth(1:2,j)=re;
end
iteration=iteration+1;
ssr1=result.ssr;
tor=abs((ssr1-ssr0)/ssr0)
end

v1=trace(S);
v2=trace(S'*S);
var=zeros(NT,K);
for p=1:K
var(:,p)=diag(M(:,:,p)*M(:,:,p)')*(result.res'*result.res)/(NT-2*v1+v2);
result.beta(:,p)=M(:,:,p)*y;
end
se=sqrt(var);
t=result.beta./se;
sigma=sqrt(result.ssr/(NT-2*v1+v2));
score=NT*log(result.ssr/NT)+NT*log(2*pi)+NT*(NT+v1)/(NT-2-v1);
t2=clock;
time=etime(t2,t1);
result.se=se;
result.t=t;
result.iterbdwt=iterbdwt;
%result.r0=r0;
result.iteration=o-2;
result.v1=v1;
result.v2=v2;
result.sigma=sigma;
result.var=var;
result.bdwt=bandwidth;
result.score=score;
result.r2=1-result.ssr/sum((y-mean(y)).^2);
result.time=time;
result.resid=result.res;
