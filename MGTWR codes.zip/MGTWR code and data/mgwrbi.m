function result=mgwrbi(y,x,east,north)
t1=clock;
[n,k]= size(x);
r0=gwr2bi(y,x,east,north);
D=pdist2([east,north],[east,north]);
SD=sort(D)';
f0=r0.beta.*x;
S=r0.S;
R=r0.R;
M=r0.M;
bmin=5;
bmax=n;
bandwidth=[];
tor=1;
ssr1=r0.ssr;
iteration=1;
fy=(1+sqrt(5))/2;
while tor>10^-3
ssr0=ssr1;o=1;
for j=1:k
%golden section
a=bmin;b=bmax;
c=round(b-(b-a)/fy);d=round(a+(b-a)/fy);
fa=mgwrscore2bi(a,y,x,D,SD,f0,j);
fb=mgwrscore2bi(b,y,x,D,SD,f0,j);
fc=mgwrscore2bi(c,y,x,D,SD,f0,j);
fd=mgwrscore2bi(d,y,x,D,SD,f0,j);
ee=[];
while c~=d&c~=a&d~=b
    if fc<fd
        b=d;fb=fd;d=c;fd=fc;c=floor(b-(b-a)/fy);fc=mgwrscore2bi(c,y,x,D,SD,f0,j);
    elseif fc>fd
        a=c;fa=fc;c=d;fc=fd;d=ceil(a+(b-a)/fy);fd=mgwrscore2bi(d,y,x,D,SD,f0,j);
    else
        if a>b
           a=c;fa=fc;c=d;fc=fd;d=ceil(a+(b-a)/fy);fd=mgwrscore2bi(d,y,x,D,SD,f0,j);
        else
           b=d;fb=fd;d=c;fd=fc;c=floor(b-(b-a)/fy);fc=mgwrscore2bi(c,y,x,D,SD,f0,j);
        end
    end
end
if b-a<3
ee=[a,b,c,d];
ef=[fa,fb,fc,fd];
ea=find(ef<min(ef)+0.1^10);
ea=ea(1);
bdwt=ee(ea);
else
ee=a:b;ef=[];
ef(1)=fa;ef(size(ee,2))=fb;
for i=1:(size(ee,2)-2)
ef(i+1)=mgwrscore2bi(ee(1,i+1),y,x,D,SD,f0,j);
end
ea=find(ef<min(ef)+0.1^10);
ea=ea(1);
bdwt=ee(ea);
end
iterbdwt(iteration,o)=bdwt;
o=o+1;
result= mgwrinf2bi(bdwt,y,x,D,SD,f0,j,S,R,M);
f0=result.f0;
S=result.S;
R=result.R;
M=result.M;
bandwidth(1,j)=bdwt;
end
iteration=iteration+1;
ssr1=result.ssr;
tor=abs((ssr1-ssr0)/ssr0)
end
v1=trace(S);
v2=trace(S'*S);
var=[];
for p=1:k
var(:,p)=diag(M(:,:,p)*M(:,:,p)')*(result.res'*result.res)/(n-2*v1+v2);
result.beta(:,p)=M(:,:,p)*y;
end
se=sqrt(var);
t=result.beta./se;
sigma=sqrt(result.ssr/(n-2*v1+v2));
score=n*log(result.ssr/n)+n*log(2*pi)+n*(n+v1)/(n-2-v1);
t2=clock;
time=etime(t2,t1);
result.se=se;
result.t=t;
result.iterbdwt=iterbdwt;
result.r0=r0;
result.iteration=o-2;
result.v1=v1;
result.v2=v2;
result.sigma=sigma;
result.var=var;
result.bdwt=bandwidth;
result.score=score;
result.r2=1-result.ssr/sum((y-mean(y)).^2);
result.bmin=bmin;
result.time=time;
result.resid=result.res;