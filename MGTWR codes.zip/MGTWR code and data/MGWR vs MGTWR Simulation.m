%simulation
east0=(kron(1:20,ones(1,20)))';
east=kron(ones(10,1),east0);
north0=(kron(ones(1,20),1:20))';
north=kron(ones(10,1),north0);
Q=1;
t=Q*kron([1:10]',ones(400,1));
D=zeros(4000,4000);
for i=1:4000
    for j=1:4000
        D(i,j)=sqrt((east(i)-east(j))^2+(north(i)-north(j))^2+(t(i)-t(j))^2);
    end
end
x=[ones(4000,1),randn(4000,2)];
e=randn(4000,1);

%Scenario 1 no spatial variation and no temporal variation.
beta0=3*ones(4000,1);
beta1=-1*ones(4000,1);
beta2=10*ones(4000,1);
beta=[beta0, beta1, beta2];
y1=sum(x.*beta,2)+e;
r1=mgtwr(y1,x,east0,north0);
save('r1')
%Scenario 2 large spatial variation and small temporal variation.
d=1; 
Q=0.2;
t=Q*kron([1:10]',ones(400,1));
D=zeros(4000,4000);
for i=1:4000
    for j=1:4000
        D(i,j)=sqrt((east(i)-east(j))^2+(north(i)-north(j))^2+(t(i)-t(j))^2);
    end
end
rh=exp(-0.5*D.^2/d.^2);

beta0=mvnrnd(zeros(4000,1),rh)';
beta1=mvnrnd(zeros(4000,1),rh)';
beta2=mvnrnd(zeros(4000,1),rh)';
beta=[beta0, beta1, beta2];
y2=sum(x.*beta,2)+e;
r2=mgtwr(y2,x,east0,north0);
save('r2')
%Scenario 3 small spatial variation and large temporal variation.
d=10;
Q=10;
t=Q*kron([1:10]',ones(400,1));
D=zeros(4000,4000);
for i=1:4000
    for j=1:4000
        D(i,j)=sqrt((east(i)-east(j))^2+(north(i)-north(j))^2+(t(i)-t(j))^2);
    end
end
rh=exp(-0.5*D.^2/d.^2);

beta0=mvnrnd(zeros(4000,1),rh)';
beta1=mvnrnd(zeros(4000,1),rh)';
beta2=mvnrnd(zeros(4000,1),rh)';
beta=[beta0, beta1, beta2];
y3=sum(x.*beta,2)+e;
r3=mgtwr(y3,x,east0,north0);
save('r3')
%Scenario 4 large spatial variation and large temporal variation.
d=1;
Q=1;
t=Q*kron([1:10]',ones(400,1));
D=zeros(4000,4000);
for i=1:4000
    for j=1:4000
        D(i,j)=sqrt((east(i)-east(j))^2+(north(i)-north(j))^2+(t(i)-t(j))^2);
    end
end
rh=exp(-0.5*D.^2/d.^2);

beta0=mvnrnd(zeros(4000,1),rh)';
beta1=mvnrnd(zeros(4000,1),rh)';
beta2=mvnrnd(zeros(4000,1),rh)';
beta=[beta0, beta1, beta2];
y4=sum(x.*beta,2)+e;
r4=mgtwr(y4,x,east0,north0);
save('r4')
%*******
m=400;
[i,j] = meshgrid(min(east0):(max(east0)-min(east0))/m:max(east0),min(north0):(max(north0)-min(north0))/m:max(north0));
xmin=min(east0);
xmax=max(east0);
ymin=min(north0);
ymax=max(north0);
for t=1:10
    figure(t)
   b= beta0((1+400*(t-1)):(400+400*(t-1)));
Z1=griddata(east0,north0,reshape(b,400,1),i,j,'nearest');
zmin=min(reshape(b,400,1));
zmax=max(reshape(b,400,1));
mesh(i,j,Z1);
axis([xmin xmax ymin ymax zmin zmax]);
view(2);
colorbar
colormap jet
hold on
plot3(east0,north0,zmax*ones(size(east0)),'black.','markersize',10);
hold off
end