function result= mgtwrinf(bdwt,y,x,D,SD,f0,j,S,R,M)
n= size(D,1);NT=size(x,1);T=NT/n;cm=zeros(NT,NT);
e0=y-sum(f0,2)+f0(:,j);
bs=bdwt(1);bt=bdwt(2);
r=zeros(NT,NT);
for time =1:T
wt=zeros(T,1);
index2=find(abs(time*ones(T,1)-(1:T)')<=bt);
Z=(ones(T,1)-(time*ones(T,1)-[1:T]').^2./(bt^2)).^2;
wt(index2)=Z(index2);
for iter = 1:n
ws = zeros(n,1);        
a=SD(iter,bs);
index=find(D(iter,:)<=a+0.1^10);
ws(index)=((1-(D(iter,index).^2)./(a^2)).^2)'; 
w=kron(wt,ws);

wx=w.*x(:,j);
C=(x(:,j)'*wx)\wx';
r(iter+(time-1)*n,:)=x(iter+(time-1)*n,j)*C;
cm(iter+(time-1)*n,:)=C;
end
end

ehat=r*e0;
newf0=f0;
newf0(:,j)=ehat;
res=e0-ehat;
Aj=r;
newR=R;
newR(:,:,j)=Aj-Aj*S+Aj*R(:,:,j);
newM=M;
newM(:,:,j)=cm-cm*S+cm*R(:,:,j);
newS=S-R(:,:,j)+newR(:,:,j);
result.bdwt=bdwt;
result.f0=newf0;
result.yhat=newS*y;
result.S=newS;
result.R=newR;
result.M=newM;
result.res=res;
result.ssr=res'*res;
end