function score= mgtwrscore(bdwt,y,x,D,SD,f0,j)
n= size(D,1); NT=size(x,1);T=NT/n;
e0=y-sum(f0,2)+f0(:,j);
bs=bdwt(1);bt=bdwt(2);
r=zeros(NT,NT);
for time =1:T
wt=zeros(T,1);
index2=find(abs(time*ones(T,1)-(1:T)')<bt);
Z=(ones(T,1)-(time*ones(T,1)-[1:T]').^2./(bt^2)).^2;
wt(index2)=Z(index2);
for iter = 1:n
ws = zeros(n,1);        
a=SD(iter,bs);
index=find(D(iter,:)<=a+0.1^10);
ws(index)=((1-(D(iter,index).^2)./(a^2)).^2)'; 
w=kron(wt,ws);

wx=w.*x(:,j);
C=(x(:,j)'*wx)\wx';
r(iter+(time-1)*n,:)=x(iter+(time-1)*n,j)*C;
end
end

S=r;
ehat=S*e0;
res=e0-ehat;
v1=trace(S);
score=NT*log((res'*res)/NT)+NT*log(2*pi)+NT*(NT+v1)/(NT-2-v1);
if (NT-2-v1)<0
score=inf;
end
end